package exception;

import java.lang.Exception;

public class ErroInserirException extends Exception{
	public ErroInserirException(String mensagem) {
		super(mensagem);
	}

}