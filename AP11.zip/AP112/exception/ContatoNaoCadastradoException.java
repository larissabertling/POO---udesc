package exception;

import java.lang.Exception;

public class ContatoNaoCadastradoException extends Exception {
    
    public ContatoNaoCadastradoException(){
        super("Contato nao cadastrado!");
    }
}
