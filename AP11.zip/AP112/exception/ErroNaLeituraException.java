package exception;

import java.lang.Exception;

public class ErroNaLeituraException extends ErroArquivoException{
    
    public ErroNaLeituraException(){
        super("Erro durante a leitura do arquivo");
    }
}
