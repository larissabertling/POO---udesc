package exception;

import java.lang.Exception;

public class ContatoJaCadatradoException extends Exception{

    public ContatoJaCadatradoException(){
        super("Contato ja cadastrado!");
        
    }
    
}
