package exception;

import java.lang.Exception;

public class ErroAtualizarException extends Exception{
	public ErroAtualizarException(String mensagem) {
		super(mensagem);
	}

}