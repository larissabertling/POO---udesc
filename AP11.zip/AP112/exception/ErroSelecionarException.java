package exception;

import java.lang.Exception;

public class ErroSelecionarException extends Exception{
	public ErroSelecionarException(String mensagem) {
		super(mensagem);
	}
}