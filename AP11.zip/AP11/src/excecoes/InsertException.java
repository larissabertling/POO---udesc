package excecoes;

import java.lang.Exception;

public class InsertException extends Exception{
    public InsertException(String mensagem){
        super(mensagem);
    }
}