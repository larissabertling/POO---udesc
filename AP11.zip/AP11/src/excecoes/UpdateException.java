package excecoes;

import java.lang.Exception;

public class UpdateException extends Exception{
    public UpdateException(String mensagem){
        super(mensagem);
    }
}