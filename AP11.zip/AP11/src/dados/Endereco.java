package dados;

public class Endereco {
	    private int id;
	    private String rua;
	    private int numero;
	    private String cidade;
	    private int idPessoa;
	}

