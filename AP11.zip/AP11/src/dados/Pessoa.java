package dados;

public class Pessoa {
	 private int id;
	 private String nome;
	 private int cpf;
	 private int telefone;
	 private Endereco endereco;
}
