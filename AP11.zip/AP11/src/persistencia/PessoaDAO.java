package persistencia;

public class PessoaDAO {

}
