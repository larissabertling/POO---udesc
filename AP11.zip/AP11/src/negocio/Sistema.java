package negocio;

public class Sistema {

}
