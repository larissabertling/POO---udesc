AULA PRÁTICA 1 (2)

//EXERCÍCIO 2


import java.util.Arrays;
import java.util.Scanner;

public class Exercicio2  {
public static void main ( String [ ] args ) {

  String pessoa1;
  String pessoa2;
  String pessoa3;

    Scanner leitor = new Scanner (System.in) ;
    System.out.print("Digite o primeiro nome:");
    pessoa1=leitor.nextLine();
    System.out.print("Digite o segundo nome:");
    pessoa2=leitor.nextLine();
    System.out.print("Digite o terceiro nome:");
    pessoa3=leitor.nextLine();

    System.out.println ( "Digite a idade:");
    int[] idade = new int[3];
    for ( int i = 0 ; i < 3 ; i++)
    idade [i] = leitor.nextInt ( );   

    System.out.println("Os nomes são: " + pessoa1 + ", " + pessoa2 + " e " +pessoa3);
    System.out.println( "As idades são:" + Arrays.toString(idade));
}
}

