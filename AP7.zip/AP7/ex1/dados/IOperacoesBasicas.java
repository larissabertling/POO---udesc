package ex1.dados;

public class IOperacoesBasicas <T>{
    
    public T soma(T operador1, T operador2);
    public T subtracao(T operador1, T operador2);
}
