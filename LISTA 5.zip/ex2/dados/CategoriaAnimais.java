package ex2.dados;

public enum  CategoriaAnimais {
    CAO, GATO, SAPO, RATO, COBRA;
}
