package ex2.dados;

public class Gato implements Animal {

	@Override
	public String emitirSom() {
		return "Miau";
	}

}