package ex2.dados;

public class Sapo implements Animal {

	@Override
	public String emitirSom() {
		return "Croac Croac";
	}

}