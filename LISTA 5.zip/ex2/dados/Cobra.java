package ex2.dados;

public class Cobra implements Animal {

	@Override
	public String emitirSom() {
		return "SSSSSSSSS";
	}

}