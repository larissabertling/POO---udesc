package ex2.dados;

public class Rato implements Animal {

	@Override
	public String emitirSom() {
		return "Quiiii";
	}

}