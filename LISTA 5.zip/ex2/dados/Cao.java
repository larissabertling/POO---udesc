package ex2.dados;

public class Cao implements Animal {

	@Override
	public String emitirSom() {
		return "Au-au";
	}

}