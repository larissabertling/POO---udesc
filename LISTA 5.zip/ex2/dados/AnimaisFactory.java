package ex2.dados;


public class AnimaisFactory {
	private static AnimaisFactory instance = null;
	private AnimaisFactory() {
		
	}
	public static AnimaisFactory getInstance() {
		if(instance == null) {
			instance = new AnimaisFactory();
		}
		return instance;
	}
	public Animal createAnimal(CategoriaAnimais categoriaAnimais) {
		switch(categoriaAnimais) {
		case CAO:
			return new Cao();
		case COBRA:
			return new Cobra();
		case GATO:
			return new Gato();
		case RATO:
			return new Rato();
		case SAPO:
			return new Sapo();
		default:
			throw new IllegalArgumentException("Tipo de animal inexistente");
		}
	}

}