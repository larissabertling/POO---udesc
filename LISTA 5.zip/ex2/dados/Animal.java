package ex2.dados;

public interface Animal {
	public String emitirSom();

}