package ex3.dados;

public interface Observador {
	public void atualizar(Object objeto);

}