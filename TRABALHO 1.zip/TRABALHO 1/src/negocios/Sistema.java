package negocios;

import dados.*;
import java.util.ArrayList;
import java.util.List;


public class Sistema {
    
    ArrayList<Usuario> listaDeUsuarios = new ArrayList<>();
    
    
    public List<Gastos> getGastos(Usuario usuario){
        return usuario.getGastos();
        
    }
    
    public void cadastrarUsuario(Usuario usuario) {
        this.listaDeUsuarios.add(usuario);
    	
    }
    
    public void cadastrarGastos(Usuario usuario, Gastos gastos) {
        usuario.cadastrarGasto(gastos);
    
    }

    public void alterarGasto(Usuario usuario, Gastos antigo, Gastos novo){
        List <Gastos> gastos = usuario.getGastos();
        int pos = gastos.indexOf(antigo);
        gastos.set(pos, novo);
    }
    
    public void removerGastos(Usuario usuario, Gastos gasto) {
    	List <Gastos> gastos = usuario.getGastos();
        gastos.remove(gasto);

    }
    
    public List<Gastos> filtrarMes(Usuario usuario, int mes){
        List<Gastos> gastos = usuario.getGastos();
        List <Gastos> aux = new ArrayList<>();
        for(int i =0; i< gastos.size(); i++){
            if(gastos.get(i).getMes() == mes){
                aux.add(gastos.get(i));
            }
        } return aux;
    }
    
    public List<Gastos> filtrarCategoria(Usuario usuario, Categoria categoria){
    	List<Gastos> gastos = usuario.getGastos();
        List <Gastos> aux = new ArrayList<>();
        for(int i =0; i< gastos.size(); i++){
            if(gastos.get(i).getCategoria() == categoria){
                aux.add(gastos.get(i));
            }
        } return aux;
    }

    public Usuario loginUsuario(String login, String senha){
        for(int i =0; i< this.listaDeUsuarios.size(); i++){
            if(this.listaDeUsuarios.get(i).getLogin().equals(login) && this.listaDeUsuarios.get(i).getSenha().equals(senha)){
                return this.listaDeUsuarios.get(i);
            }
        } return null;
    }
}
    