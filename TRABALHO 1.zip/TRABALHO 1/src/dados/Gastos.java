package dados;

public class Gastos {
	
	 private int id;
     private String nome;
     private String descricao;
     private Categoria categoria;
     private float valor;
     private int dia;
     private int mes;
     private int ano;

 
 public Gastos(int id, String nome, String descricao, Categoria categoria, float valor, int dia, int mes, int ano){
     this.nome = nome;
     this.descricao = descricao;
     this.valor = valor;
     this.categoria = categoria;
     this.dia = dia;
     this.mes = mes;
     this.ano = ano;
 }

 public void Extra(){
    
}

 public String getNome() {
     return this.nome;
 }

 public void setNome(String nome) {
     this.nome = nome;
 }

 public String getDescricao() {
     return this.descricao;
 }

 public void setDescricao(String descricao) {
     this.descricao = descricao;
 }
 public float getValor() {
     return this.valor;
 }
 public void setValor(float valor){
     this.valor = valor;
 }
 public int getID() {
     return this.id;
 }
 public int getDia() {
     return this.dia;
 }

 public void setDia(int dia) {
     this.dia = dia;
 }

 public int getMes() {
     return this.mes;
 }

 public void setMes(int mes) {
     this.mes = mes;
 }
 public int getAno() {
     return this.ano;
 }

 public void setAno(int ano) {
     this.ano = ano;
 }

 public Categoria getCategoria() {
     return this.categoria;
 }

 public void setCategoria(Categoria categoria){
    this.categoria = categoria;
 }

 public String toString() {
     return "\nID: " + id + "\nNome: " + nome + "\nDescricao: " + descricao + "\nValor: " + valor + "\nDia: " + dia +  "\nMes: " + mes +  "\nAno: " + ano  + "\n";

 }
}
