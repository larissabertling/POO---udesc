package dados;

public enum Categoria {
	
	COMIDA, LAZER, EDUCACAO, SAUDE, TRANSPORTE, OUTROS;
    
}

