package apresentacao;

import dados.Categoria;
import dados.Gastos;
import dados.Usuario;
import negocios.Sistema;

public class Teste {
    
    public static void main(String[] args) {
        Sistema sistema = new Sistema();

        Usuario usuario = new Usuario("fulano", "123");
        sistema.cadastrarUsuario(usuario);

        Gastos gastos = new Gastos(22, "mc donalds", "muito bom", Categoria.COMIDA, 25, 03, 06, 2022);
        sistema.cadastrarGastos(usuario, gastos);

        System.out.println(sistema.getGastos(usuario));
    }
}
