package ex3.excecao;

import java.lang.Exception;

public class NomeInvalidoException extends Exception{
	public NomeInvalidoException() {
		
	}
	public NomeInvalidoException(String mensagem) {
		super(mensagem);
	}

}