package ex2.excecao;

import java.lang.Exception;

public class PilhaVaziaException extends Exception {
	public PilhaVaziaException() {
		
	}
	public PilhaVaziaException(String mensagem) {
		super(mensagem);
	}

}