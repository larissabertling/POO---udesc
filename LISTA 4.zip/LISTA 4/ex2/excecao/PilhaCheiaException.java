package ex2.excecao;

import java.lang.Exception;

public class PilhaCheiaException extends Exception {
	public PilhaCheiaException() {
		
	}
	public PilhaCheiaException(String mensagem) {
		super(mensagem);
	}

}