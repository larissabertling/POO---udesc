package ex2.apresentacao;

import java.util.*;

import ex2.dados.*;
import ex2.excecao.*;


public class Main {
	static SistemaDeProcessos sistema = new SistemaDeProcessos();
	static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args){
		Juiz juiz1 = new Juiz(2);
		juiz1.setNome("Joao");
		sistema.cadastrarJuiz(juiz1);

		Juiz juiz2 = new Juiz(5);
		juiz2.setNome("Roberto");
		sistema.cadastrarJuiz(juiz2);

		Juiz juiz3 = new Juiz(3);
		juiz3.setNome("Augusto");
		sistema.cadastrarJuiz(juiz3);
		
		Processo processo1 = new Processo(1,"Processo 1");
		Processo processo2 = new Processo(2,"Processo 2");
		Processo processo3 = new Processo(3,"Processo 3");
		Processo processo4 = new Processo(4,"Processo 4");
		Processo processo5 = new Processo(5,"Processo 5");
		Processo processo6 = new Processo(6,"Processo 6");
		Processo processo7 = new Processo(7,"Processo 7");
		Processo processo8 = new Processo(8,"Processo 8");
		Processo processo9 = new Processo(9,"Processo 9");
		Processo processo10 = new Processo(10,"Processo 10");
		
		sistema.cadastrarProcessos(processo1);
		sistema.cadastrarProcessos(processo2);
		sistema.cadastrarProcessos(processo3);
		sistema.cadastrarProcessos(processo4);
		sistema.cadastrarProcessos(processo5);
		sistema.cadastrarProcessos(processo6);
		sistema.cadastrarProcessos(processo7);
		sistema.cadastrarProcessos(processo8);
		sistema.cadastrarProcessos(processo9);
		sistema.cadastrarProcessos(processo10);
		
		distribuirProcessos();
		
		imprimirJuizes();
		
		testeExcecao1(processo1);
		testeExcecao2();
	
	}
	
	
	
	public static void distribuirProcessos(){
		try {
			sistema.distribuirProcessos();
		}
		catch(PilhaCheiaException e) {
			System.err.println(e.getMessage());
		}
		catch(ProcessoSemJuizException e) {
			System.err.println(e.getMessage());
		}
		
	}
	public static void testeExcecao1(Processo processo) {
		List<Juiz> testeExcecao = sistema.retornarLista();
		Juiz j = testeExcecao.get(0);
		try {
			j.cadastrarProcesso(processo);
		}
		catch(PilhaCheiaException e){
			System.err.println(e.getMessage());
		}
		
	}
	public static void testeExcecao2() {
		Juiz j = new Juiz(5);
		j.setNome("Claudio");
		try {
			Processo p = j.removerProcesso();
		}
		catch(PilhaVaziaException e) {
			System.err.println(e.getMessage());
		}
	}
	public static void imprimirJuizes() {
		List<Juiz> lista = sistema.retornarLista();
		for(Juiz j : lista) {
			System.out.println(j);
		}
	}
}