package ex1.dados;

public class Mod implements IOperacao {

	public int executar(int m1, int m2) {
		while(m1 >= m2){
            m1 = m1 - m2;
        }
		return m1;
		
	}

}