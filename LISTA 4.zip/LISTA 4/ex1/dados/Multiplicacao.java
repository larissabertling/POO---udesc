package ex1.dados;

public class Multiplicacao extends Soma{
	
	public int executar(int m1, int m2) {
		int resultado = 0;
		for(int i=0;i<m2;i++) {
			
			resultado = super.executar(resultado, m1);
		}
		return resultado;
	}

}