package ex1.dados;

public interface IOperacao {
	public int executar(int m1,int m2);
}