package ex1.dados;

public class Soma implements IOperacao{
	public int executar(int m1, int m2) {
		int resultado = m1 + m2;
		return resultado;
	}

}