package ex1.dados;

public class MDC implements IOperacao{
	public int executar(int m1, int m2) {
		int menor;

		if(m1 > m2) {
			menor = m2;
		}else {
			menor = m1;
		}
		int mdc = 0;
		for(int i = 1; i < menor;i++) {

			int a = m1;  //primeiro num
			int b = m2;  //segundo num
			while(a >= i) {
				a = a - i;				
			}
			while(b >= i) {
				b = b - i;				
			}
			if(b == 0 && b ==0) {
				mdc = i;
			}
			
		}
		return mdc;
	}
}