package ex1.apresentacao;

import ex1.dados.*;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		List<IOperacao> lista = new LinkedList<IOperacao>();
		Soma soma = new Soma();
		Multiplicacao mul = new Multiplicacao();
		MDC mdc = new MDC();
		Mod mod = new Mod();

		lista.add(soma);
		lista.add(mul);
		lista.add(mdc);
		lista.add(mod);
		int  i = 0;

		while(i<4) {
			Random random = new Random();
			int m1 = random.nextInt(100);
			int m2 = random.nextInt(100);
			int resultado1 = lista.get(0).executar(m1, m2);
			int resultado2 = lista.get(1).executar(m1, m2);
			int resultado3 = lista.get(2).executar(m1, m2);
			int resultado4 = lista.get(3).executar(m1, m2);
			System.out.println("Valor 1: "+m1+" Valor 2: "+m2);
			System.out.println("Soma: "+resultado1+" Multiplicacao: "+resultado2+" MDC: "+resultado3+" MOD: "+resultado4);
			System.out.println();
			i++;
		}
	}
}