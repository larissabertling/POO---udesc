package excecao;

import java.lang.Exception;

public class UpdateException extends Exception {
    public UpdateException() {
        super("Falha ao alterar");
    }

    public UpdateException(String mensagem) {
        super(mensagem);
    }

}
