package excecao;

import java.lang.Exception;

public class DeleteException extends Exception {
    public DeleteException() {
        super("Falha ao remover");
    }

    public DeleteException(String mensagem) {
        super(mensagem);
    }

}
