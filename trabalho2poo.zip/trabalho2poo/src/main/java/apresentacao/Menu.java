package apresentacao;

import dados.*;
import negocio.*;
import excecao.*;
import java.util.*;

public class Menu {
    static Gastos gastos = null;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        Sistema sistema = Sistema.getInstancia();
    }
}

    /*private static void mostrarOpcoes() {
        System.out.println("\nDigite a opcao desejada:");
        System.out.println("[1] - Cadastrar despesa");
        System.out.println("[2] - Filtrar mes");
        System.out.println("[3] - Filtrar categoria");
        System.out.println("[4] - Remover um gasto");
        System.out.println("[5] - Alterar dados de um gasto");
        System.out.println("[0] - Sair");
    }

    private static void mostrarCategorias() {
        System.out.println("\nDigite a categoria desejada:");
        System.out.println("[1] - Alimentacao");
        System.out.println("[2] - Saude");
        System.out.println("[3] - Transporte");
        System.out.println("[4] - Lazer");
        System.out.println("[5] - Educacao");
        System.out.println("[6] - Outros");
    }
}

*/