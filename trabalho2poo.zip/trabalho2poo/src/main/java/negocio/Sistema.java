package negocio;

import java.util.LinkedList;
import java.util.List;


import dados.*;
import excecao.*;
import persistencia.*;

public class Sistema {
    private UsuarioDAO usuarioDAO;
    private GastosDAO gastosDAO;
    private int ID_logado = -1;
    private List<Gastos> gastos_logado = new LinkedList<Gastos>();
   
    

    public void login(String login, String senha) throws SelectException {
        Usuario usuario = usuarioDAO.login(login);

        if(usuario == null){
            System.out.println("Usuário não registrado! ");
        }

        if(usuario.getSenha().equals(senha)){
            ID_logado = usuario.getId();
            LoadGastos();
        }else{
            System.out.println("Senha Incorreta! ");
        }
    }

    
    public void addGasto(Gastos gastos) throws InsertException, SelectException{
        gastos.setId_usuario(ID_logado);
        gastosDAO.insert(gastos);
    }

    public List<Gastos> seeAllGastos() throws SelectException{
        LoadGastos();
        return gastos_logado;
    }

    public Gastos selectGasto(int id) throws SelectException{
        return gastosDAO.select(id);
    }

    public List<Gastos> selectGastosFromCategoria(int cat) throws SelectException{
        return gastosDAO.selectFromCateg(cat, ID_logado);
    }

    public List<Gastos> selectGastosFromMes(int mes) throws SelectException{
        String mesString = "";
        if(mes > 0 && mes <=12){
            if(mes < 10){
                mesString += "0"+mes;
            }else{
                mesString += mes;
            }
        }
        return gastosDAO.selectFromMes(mesString, ID_logado);
    }

    public void removeGasto(Gastos gastos) throws DeleteException{
        gastos.setId_usuario(ID_logado);
        gastosDAO.delete(gastos);
    }

    public void updateGasto(Gastos gastos) throws UpdateException{
        gastos.setId_usuario(ID_logado);
        gastosDAO.update(gastos);
    }

    private void LoadGastos() throws SelectException{
        gastos_logado = gastosDAO.selectAll(ID_logado);
    }

    public void addUser(Usuario usuario) throws InsertException{
        usuarioDAO.insert(usuario);
    }

    public void removeUser(Usuario usuario) throws DeleteException{
        usuarioDAO.delete(usuario);
    }
    
    public List<Gastos> getGastos(Usuario usuario){
        return usuario.getGastos();  
    }


    public Sistema getInstancia() {
        return null;
    }
}
    
