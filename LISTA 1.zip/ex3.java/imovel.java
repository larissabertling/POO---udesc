public class imovel{
    private String nome;
    private float largura;
    private float comprimento;
    private float valor;
    
    public imovel () {
	}

    public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getLargura() {
		return largura;
	}
	public void setLargura(float largura) {
		this.largura = largura;
	}
	public float getComprimento() {
		return comprimento;
	}
	public void setComprimento(float comprimento) {
		this.comprimento = comprimento;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
    public float calcularArea() {
		return comprimento * largura;
	}

    public String toString() {
        return "Nome do Imovel: " + nome + " Largura: " + largura + " Comprimento: " + comprimento + "Area Total: " + String.format("%.02f", calcularArea()) + "m²" + "Valor do Imovel: " + String.format("%.02f", valor) + "R$\n";
    }

}