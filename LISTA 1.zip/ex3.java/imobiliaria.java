public class imobiliaria {
    private String nome;
    private imovel [] imoveis = new imovel [50];
    private int quantImoveis = 0;


    public imobiliaria () {
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public imovel[] getImoveis() {
		return imoveis;
	}
	public void setImoveis(imovel[] imoveis) {
		this.imoveis = imoveis;
	}
	public int getQuantImoveis() {
		return quantImoveis;
	}


	public String toString() {
        return "Nome: " + nome + " Quantidade de Imoveis: " + quantImoveis + " Imovel: " + imoveis;
    }

    public boolean addImovel(imovel imovel) {
		if (quantImoveis < imoveis.length) {
			imoveis[quantImoveis] = imovel;
			quantImoveis++;
			return true;
		}
		System.out.println("Nao é possivel add mais imoveis! ");
		return false;
	}	


    imovel[ ] filtrarPorArea (float x) {
    int quantMax = 0;
    for (int i = 0; i < quantImoveis; i++) {
        if (imoveis[i].calcularArea() <= x) {
            quantMax++;
        }
    }
    imovel[] mov = new imovel[quantMax];
    int id = 0;
    for (int i = 0; i < quantImoveis; i++) {
        if (imoveis[i].calcularArea() <= x) {
            mov[id] = imoveis[i];
            id++;
        }
    }
    return mov;
}
}