import java.util.Scanner;

public class principal {
    private static imobiliaria imobiliaria = new imobiliaria();
    private static Scanner s = new Scanner (System.in);

    public static void main(String[] args) {
		System.out.printf ("\n +imobiliaria.getNome()+\n");

       
        int op = -1;
		while (op != 0) {
			menu();
			op = Integer.parseInt(s.nextLine());
			switch (op) {
			case 0:
				break;
			case 1:
				cadastrarImovel();
				break;
			case 2:
				mostrarImoveis();
				break;
			default:
				System.out.println("Opcao nao cadastrada!");
			}
		}
	}	

    public static void menu() {
		System.out.println("\nEscolha uma opcao");
		System.out.println("0 - Sair");
		System.out.println("1 - Cadastrar Imovel");
		System.out.println("2 - Exibir Imoveis");   
	}

	public static void cadastrarImovel () {			
			imovel mov = new imovel();
			
			System.out.println("Digite o nome do imovel: ");
			String nome = s.nextLine();
			mov.setNome(nome);
			
			System.out.println("Digite o valor do imovel: ");
			float valor = Float.parseFloat(s.nextLine());
			mov.setValor(valor);
			
			System.out.println("Digite a largura do imovel: ");
			float largura = Float.parseFloat(s.nextLine());
			mov.setLargura(largura);
			
			System.out.println("Digite o comprimento do imovel: ");
			float comprimento = Float.parseFloat(s.nextLine());
			mov.setComprimento(comprimento);
			
			imobiliaria.addImovel(mov);
	}	
	public static void mostrarImoveis(){
		int option = -1;
		System.out.println("Escolha uma opcao");
		System.out.println("1 - Ver todos os imoveis do sistema");
		System.out.println("2 - Ver apenas imoveis filtrados por area");
		option = Integer.parseInt(s.nextLine());
		switch (option) {
		case 1:
			System.out.println(imobiliaria.toString());
			break;
		case 2:
			System.out.println("Qual a area maxima?");
			float area = Float.parseFloat(s.nextLine());
			imovel[] imov = imobiliaria.filtrarPorArea(area);
			for (int i = 0; i < imov.length; i++) {
				System.out.println(imov[i].toString() + "\n---------------------");
			}
			break;
		default:
			System.out.println("ERRO");
		}
	}
}


