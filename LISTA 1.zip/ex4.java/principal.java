public class principal {
    
	public static void main(String[] args) {
	    Sorteador sorteador = new Sorteador();

        Pessoa p1 = new Pessoa ( ) ;
		p1.setNome("Larissa Bertling") ;
		p1.setCodigo (23);
		p1.setIdade (19);
	
        Pessoa p2 = new Pessoa ( ) ;
		p2.setNome("Leticia Capitani") ;
		p2.setCodigo (54);
		p2.setIdade (20);
	
        Pessoa p3 = new Pessoa ( ) ;
		p3.setNome("Karla Joriatti") ;
		p3.setCodigo (12);
		p3.setIdade (21);

        sorteador.setPessoas(p1);
		sorteador.setPessoas(p2);
		sorteador.setPessoas(p3);
		
		System.out.println("\nO sorteado é:\n" + sorteador.sortearProximo().toString());
	}

}
	
