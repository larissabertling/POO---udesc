import java.util.Random;

public class Sorteador {
    
    private Pessoa [] pessoas = new Pessoa [50];
    private int quantPessoas;
    private Random sorteador = new Random();

public Pessoa[] getPessoas(){
    return pessoas;
}
public void setPessoas(Pessoa p){
    if (this.quantPessoas < 3){
        pessoas[this.quantPessoas] = p;
        this.quantPessoas++;
    }
}
public int getQuantPessoas(){
    return quantPessoas;
}
public void setQuantPessoas(int quantPessoas) {
    this.quantPessoas = quantPessoas;
}

public Pessoa sortearProximo(){
    int sorteadoIndex  = sorteador.nextInt(quantPessoas);
    Pessoa sorteada = pessoas[sorteadoIndex];
    for (int i = sorteadoIndex; i < quantPessoas; i++)
        pessoas[i] = pessoas[i+1];
    quantPessoas--;
    return sorteada;
}
}