package dados;
public class livro {
    private int codigo;
    private String titulo;
    private String categoria;
    
    public livro (){

    }
    public String getTitulo (){
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getCategoria(){
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public int getCodigo(){
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String toString() {
        return "Código do Livro: " + codigo + " Título: " + titulo + " Categoria: " + categoria ;
    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        livro other = (livro) obj;
        return Objects.equals(titulo, other.titulo);
    }
}
    

    
   
