package dados;


import java.util.Objects;

public class locacao {
    private int codigoReserva;
    private int quantidade ;
    private String dataEmprestimo;
    private String dataDevolucao ;


public locacao (){

}
public String getDataEmprestimo (){
    return dataEmprestimo;
}
public void setDataEmprestimo(String dataEmprestimo) {
    this.dataEmprestimo = dataEmprestimo;
}
public String getDDataDevolucao (){
    return dataDevolucao;
}
public void setDataDevolucao(String dataDevolucao) {
    this.dataDevolucao = dataDevolucao;
}
public int getCodigoReserva (){
    return codigoReserva;
}
public void setCodigoReserva(int codigoReserva) {
    this.codigoReserva = codigoReserva;
}
public int getQuantidade (){
    return quantidade;
}
public void setQuantidade(int quantidade) {
    this.quantidade = quantidade;
}


public String toString() {
    return "Código da Reserva: " + codigoReserva + " Quantidade: " + quantidade + " Data do Empréstimo: " + dataEmprestimo + " Data de Devolução: " + dataDevolucao;
}

public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    locacao other = (locacao) obj;
    return Objects.equals(codigoReserva, other.codigoReserva);
}
}



