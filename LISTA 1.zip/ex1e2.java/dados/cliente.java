package dados;
public class cliente {
    private String nome;
    private int codigo;
    private int cpf;
    private int numReserva;
    
    public cliente (){

    }
    public String getNome (){
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getCodigo (){
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public int getCpf (){
        return cpf;
    }
    public void setCpf(int cpf) {
        this.cpf = cpf;
    }
    public int getNumReserva (){
        return numReserva;
    }
    public void setNumReserva(int numReserva) {
        this.numReserva = numReserva;
    }
    public String toString() {
		return "Nome: " + nome + " Código: " + codigo + " CPF: " + cpf + " Número da Reserva: " + numReserva;
	}

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        cliente other = (cliente) obj;
        return Objects.equals(cpf, other.cpf);
    }
}