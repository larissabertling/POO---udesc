package dados;
public class bibliotecaria {
    private String nome;
    private int codigo;
    private int cpf;
    private int idade;
    private int carteiraDeTrabalho;
    
public bibliotecaria () {

}
 public String getNome (){
     return nome;
 }
 public void setNome(String nome) {
     this.nome = nome;
 }
 public int getCodigo (){
    return codigo;
}
public void setCodigo(int codigo) {
    this.codigo = codigo;
}
public int getCpf (){
    return cpf;
}
public void setCpf(int cpf) {
    this.cpf = cpf;
}
public int getIdade (){
    return idade;
}
public void setIdade(int idade) {
    this.idade = idade;
}
public int getCarteiraDeTrabalho (){
    return carteiraDeTrabalho;
}
public void setCarteiraDeTrabalho(int carteiraDeTrabalho) {
    this.carteiraDeTrabalho = carteiraDeTrabalho;
}
public String toString() {
    return "Nome: " + nome + " Código: " + codigo + " CPF: " + cpf + " Idade: " + idade + "Número Carteira de Trabalho: " + carteiraDeTrabalho ;
}

public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    bibliotecaria other = (bibliotecaria) obj;
    return Objects.equals(nome, other.nome);
}
}