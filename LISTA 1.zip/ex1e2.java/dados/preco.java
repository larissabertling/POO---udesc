package dados;

public class preco {
    private float valorUnitario;
    private int quantidade ;
    private float valorTotal;
    
    public preco (float valorUnitario){
        this.valorUnitario = valorUnitario;
    }
    
    public preco (){
    
    }

    public float getValorUnitario (){
        return valorUnitario;
    }
    public void setValorUnitario(float valorUnitario) {
        this.valorUnitario = valorUnitario;
    }
    public int getQuantidade (){
        return quantidade;
    }
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    public float getValorTotal(){
        return valorTotal;
    }
    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }


    public void calcularValorFinal() {
		
		if (quantidade != NULL){
            valorTotal = (valorUnitario * quantidade);

        }else{
            valorUnitario++;

        }
    }

    public String toString() {
        return "Valor Unitário da Locação: " + valorUnitario + " Quantidade de livros locados: " + quantidade + "Valor Total da Locacão: " + valorTotal + " Houve atraso? " + multaAtraso;
    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        locacao other = (preco) obj;
        return Objects.equals(valorUnitario, other.valorUnitario);
    }
}
    

