package apresentacao;

//NÃO TERMINEI

import java.util.Scanner;

import dados.*;
import negocio.sistema;

public class Principal {
	private static Scanner s = new Scanner(System.in);
	private static sistema sistema = new sistema();
	
	public static void main(String[] args) {
		int op = -1;
		while (op != 0) {
			imprimeMenu();
			op = Integer.parseInt(s.nextLine());
			switch (op) {
			case 0:
				break;
			case 1:
				cadastraNovoLivro();
				break;
			case 2:
				pesquisaLivro();
				break;
			case 3:
				alugaLivro();
				break;
			case 4:	
				devolveLivro();
				break;
			default:
				System.out.println("Opcao invalida");
				break;
			}
		}
	}

    public static void imprimeMenu () {	 	

		System.out.println("\nEscolha uma opcao:");
		System.out.println("0 - Encerrar");
		System.out.println("1 - Cadastrar");
		System.out.println("2 - Pesquisar ");
		System.out.println("3 - Alugar livro");
		System.out.println("4 - Devolver livro");	
	}

    public static void pesquisaLivro () {
		int op = -1;
		while (op != 0) {
			imprimePesquisaMenu();
			op = Integer.parseInt(s.nextLine());
			switch (op) {
			case 0:
				break;
			case 1:
				mostrarBibliotecaria();
				break;
			case 2:
				mostrarLivro(null);
				break;
			case 3:
				mostrarCliente();
				break;
			default:
				System.out.println("Opcao invalida");
				break;
			}
		}
	}

    public static void imprimePesquisaMenu () {
		System.out.println("\nEscolha uma opcao:");
		System.out.println("0 - Voltar ao menu principal");
		System.out.println("1 - Ver Bibliotecarias cadastrados");
		System.out.println("2 - Ver Livros cadastrados");
		System.out.println("3 - Ver Clientes cadastrados");
	}

    public static void mostrarBibliotecaria() {
		for (int i = 0; i < sistema.getNumBibliotecarias(); i++) {
			System.out.println("Codigo: " + i);
			System.out.println(sistema.mostrarBibliotecaria()[i].toString() + "\n");
		}
	}
	
	public static void mostraCliente() {
		for (int i = 0; i < sistema.getNumClientes(); i++) {
			System.out.println("Codigo: " + i);
			System.out.println(sistema.mostrarCliente()[i].toString() + "\n");
		}
	}
	
	public static void mostrarLivro(livro livro) {
		for (int i = 0; i < sistema.getNumLivros(); i++) {
			System.out.println("Codigo: " + i);
			System.out.println(sistema.mostrarLivro()[i].toString() + "\n");
		}
	}
