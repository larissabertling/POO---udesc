package negocio;
import dados.*;

public class sistema {
    public class Sistema {
        private cliente [] clientes = new cliente [50];
        private int numClientes = 0;
        
        private livro [] livros = new livro [50];
        private int numLivros = 0;
        
        private bibliotecaria [] bibliotecarias = new bibliotecaria [50];
        private int numBibliotecarias = 0;


        public int getNumClientes() {
            return numClientes;
        }
        public int getNumLivros() {
            return numLivros;
        }
        public int getNumBibliotecarias() {
            return numBibliotecarias;
        }	

        public void cadastraCliente(cliente cliente) {
            if (numClientes < clientes.length) {
                clientes [numClientes] = cliente;
                numClientes++;
            }
            else
                System.out.println("Numero maximo de clientes cadastrados");
        }
        public void cadastraLivro(livro livro) {
            if (numLivros < livros.length) {
                livros[numLivros] = livro;
                numLivros++;
            }
            else
                System.out.println("Numero maximo de livros cadastrados");
        }
        public void cadastraBibliotecaria(bibliotecaria fornecedor) {
            if (numBibliotecarias < bibliotecarias.length) {
                bibliotecarias[numBibliotecarias] = bibliotecaria;
                numBibliotecarias++;
            }
            else
                System.out.println("Numero maximo de bibliotecarias cadastradas");
        }
     
        public cliente[] mostrarCliente () {
            return clientes;
        }
        public livro[] mostrarLivro () {
            return livros;
        }
        public bibliotecaria[] mostrarBibliotecaria () {
            return bibliotecarias;
        }
        
    
        public cliente contemCliente (int codigo) {
            for (int i=0; i < numClientes; i++) {
                if(codigo.equals(clientes[i].getCodigo())) {
                    return clientes[i];
                }
            }
            return null;
        }
        public livro contemLivros (int codigo) {
            for (int i=0; i < numLivros; i++) {
                if(codigo.equals(livros[i].getCodigo())) {
                    return livros[i];
                }
            }
            return null;
        }
        public bibliotecaria contemBibliotearias (int codigo ) {
            for (int i=0; i < numBibliotecarias; i++) {
                if(codigo.equals(bibliotecarias[i].getCodigo())) {
                    return bibliotecarias[i];
                }
            }
            return null;
        }
    }
}