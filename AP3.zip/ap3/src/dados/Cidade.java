package dados;

public class Cidade {

    private String nome;
    private String estado;
    private Origem origem;
    private Destino[] destino;
  
    public Cidade() {
    }
        public String getNome () {
        return nome;
    }
        public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEstado () {
        return estado;
    }
        public void setEstado(String estado) {
        this.estado = estado;
    }
    public String getOrigem(){
        return origem;
    }
    public void setOrigem(String origem) {
        this.origem = origem;
} 
    public String getDestino(){
    return destino;
}
    public void setDestino(String destino) {
    this.destino = destino;
}
}


