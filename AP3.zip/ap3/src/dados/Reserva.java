package dados;
import dados.Cidade;

public class Reserva {

    private String dataVoo;
    private String horaVoo;
    private String classeVoo;
    private int poltrona;
    private int numReserva;
    private float preco;
    private boolean idaEVolta = false;
    private Reserva volta = null;
    private Cidade origem;
    private Cidade destino;
  
    public Reserva() {
    }
        public String getDataVoo () {
        return dataVoo;
    }
        public void setDataVoo(String dataVoo) {
        this.dataVoo = dataVoo;
    }
    public String getHoraVoo () {
        return horaVoo;
    }
        public void setHoraVoo(String horaVoo) {
        this.horaVoo = horaVoo;
    }
    public String getClasseVoo () {
        return classeVoo;
    }
        public void setClasseVoo(String classeVoo) {
        this.classeVoo = classeVoo;
    }
    public int getPoltrona () {
        return poltrona;
    }
        public void setPoltrona(int poltrona) {
        this.poltrona = poltrona;
    }
    public int getNumReserva () {
        return numReserva;
    }
        public void setNumReserva(int numReserva) {
        this.numReserva = numReserva;
    }
    public float getPreco () {
        return preco;
    }
        public void setPreco(float preco) {
        this.preco = preco;
    }
    public boolean getIdaEVolta () {
        return idaEVolta;
    }
        public void setIdaEVolta(boolean idaEVolta) {
        this.idaEVolta = idaEVolta;
    }

}
