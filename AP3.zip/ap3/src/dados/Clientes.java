package dados;

public class Clientes {

    private String nome;
    private String endereco;
    private int telefone;
    private int cpf;

    private Reserva reservas [] = new Reserva[10];
    private int quantReservas = 0;
  
    public Clientes() {
    }
        public String getNome () {
        return nome;
    }
        public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEndereco () {
        return endereco;
    }
        public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public int getTelefone () {
        return telefone;
    }
        public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    public int getCpf () {
        return cpf;
    }
        public void setCpf(int cpf) {
        this.cpf = cpf;
    }
    public int getQuantReserva(){
        return quantReservas;
    }
    public void reservaIda(Reserva reserva){
        if (quantReservas < 10){
            reservas[quantReservas] = volta;
            quantReservas++;
            ida.setVolta(volta);
        }else{
            System.out.println("Lista de reservas esta cheia!");
        }
    }
    public String toString(){
        return "CPF: " + cpf + ", nome: " + nome + ", endereco: " + endereco + ", telefone: " + telefone;
    }

    public boolean equals(Object o){
        if(o instanceof Cliente){
            Cliente c = (Cliente) o;
            if(c.getNome() . equals(this.getNome())){
                return true;
            }
        }
    
    return false;

    }
}

