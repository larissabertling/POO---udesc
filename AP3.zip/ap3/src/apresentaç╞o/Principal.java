package apresentação;
import dados. *;
import java.util.Scanner;
import negocio.ReservaPassagem;

public class Principal{

    private static Scanner s = new Scanner (System.in);

    private static ReservaPassagem sistema = new ReservaPassagem();

    public static void exibeMenuPrincipal(){
        System.out.println("Escolha uma opção: ");
        System.out.println("0 - Encerrar");
        System.out.println("1 - Cadastra cliente ");
        System.out.println("2 - Realizar reserva ");
        System.out.println("3 - Casastrar cidade ");
        System.out.println("4 - Mostrar clientes ");
        System.out.println("5 - Mostrar reservas ");
        System.out.println("6 - Mostrar cidades ");
    }

    public static void main (String args[]) {
        int opcao = -1;
        while 
    }




public static Cliente novoCliente
