package negocios;

public class ReservaPassagem {
    
}
private boolean clienteCadastrado(Cliente cliente){
    for(int=0; i<quantClientes, i++){
        if(listaDeClientes[i])
    }
}