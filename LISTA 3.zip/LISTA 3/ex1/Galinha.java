public class Galinha extends Animal {
	private String nome;
	
	public Galinha (String nome) {
		this.nome = nome;
	}
	
	public String emitirSom() {
		return nome + ": Cocoricó";
	}
}
