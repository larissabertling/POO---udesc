public class Macaco extends Animal {
	private String nome;
	
	public Macaco (String nome) {
		this.nome = nome;
	}

	public String emitirSom() {
		return nome + ": Uu-aa";
	}

}
