public class Cachorro extends Animal {
	private String nome;

	public Cachorro (String nome) {
		this.nome = nome;
	}
	
	public String emitirSom() {
		return nome + ": Au-au";
	}

}
