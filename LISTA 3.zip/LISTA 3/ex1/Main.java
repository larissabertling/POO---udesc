public class Main {
	public static void main(String[] args) {

		Cachorro PastorAlemao = new Cachorro ("Scooby");
		Cachorro Golden = new Cachorro ("Bella");

		Galinha Preta = new Galinha("Anita");
		Galinha Pintadinha = new Galinha("Griselda");

		Macaco Babuino = new Macaco ("Zé");
		Macaco Mandril = new Macaco ("Aroldo");


		System.out.println(PastorAlemao.emitirSom());
		System.out.println(Golden.emitirSom());
		System.out.println(Preta.emitirSom());
		System.out.println(Pintadinha.emitirSom());
		System.out.println(Babuino.emitirSom());
		System.out.println(Mandril.emitirSom());
	}
}