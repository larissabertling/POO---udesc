package ex3;

public class Main {

	public static void main(String[] args) {

        Digrafo d = new Digrafo();
        d.addVertice();
        d.addVertice();
        d.addVertice();
        d.addVertice();
        d.addVertice();
        d.addVertice();
        d.addVertice();
        d.addAresta(0, 1);
		d.addAresta(0, 2);
        d.addAresta(0, 3);
        d.addAresta(1, 1);
        d.addAresta(1, 2);
        d.addAresta(1, 3);
        d.addAresta(2, 1);
        d.addAresta(2, 2);
        d.addAresta(2, 3);
        d.addAresta(3, 4);
        d.addAresta(4, 1);
        System.out.println(d);

        Grafo g = new Grafo();
		g.addVertice();
        g.addVertice();
        g.addVertice();
		g.addAresta(0, 1);
        g.addAresta(0, 2);
        g.addAresta(1, 1);
        g.addAresta(1, 2);
        g.addAresta(2, 1);
        g.addAresta(2, 2);	
		System.out.println(g);

    }
}