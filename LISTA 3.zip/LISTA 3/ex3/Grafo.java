package ex3;

public class Grafo extends Digrafo {
    
    public void addAresta(int origem, int destino){
        super.addAresta(origem, destino);
		super.addAresta(origem, destino);
    }
}
