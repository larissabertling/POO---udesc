package ex3;

import java.util.ArrayList;
import java.util.List;


public class Digrafo {
	private Map<Integer , List <Integer>> matrizAdj2 = new MapList <MapList<Integer>>();
	
	public void addVertice() {
		MapList<Integer> a2 = new MapList<Integer>();
		for(int i = 0; i < matrizAdj2.size(); i++) {
			matrizAdj2.get(i).add(0);
			a2.add(0);
		}
		a2.add(0);
		matrizAdj2.add(a2);
	}
	
	public void addAresta(int origem, int destino) {
		try {
			matrizAdj2.get(origem).set(destino, 1);
		}
		catch ( java.lang.IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
	}



public String toString() {
    String matrizResultante = "";
     for (int i = 0; i < matrizAdj2.size(); i++) {
            for (int j = 0; j < matrizAdj2.get(i).size(); j++) {
                matrizResultante += (matrizAdj2.get(i).get(j) + "["+ i + ", " + j +"]" +" ");
            }
            matrizResultante += "\n";
        }
    return matrizResultante;
}
}