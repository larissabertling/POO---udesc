package ex2;

public class Main {
	public static void main(String[] args) {
    
        Circulo c1 = new Circulo();
		Circulo c2 = new Circulo();
		c1.setRaio(7);
		c2.setRaio(12);
		System.out.println(c1);
		System.out.println(c2);
		
		Trapezio t1 = new Trapezio();
		Trapezio t2 = new Trapezio();
		t1.setAltura(3);
		t1.setBaseMaior(6);
		t1.setBaseMenor(4);
		t2.setAltura(5);
		t2.setBaseMaior(8);
		t2.setBaseMenor(7);
		System.out.println(t1);
		System.out.println(t2);
		
		Losango l1 = new Losango();
		Losango l2 = new Losango();
		l1.setd(8);
		l1.setD(10);
		l2.setd(6);
		l2.setD(14);
		System.out.println(l1);
		System.out.println(l2);
	}
}
