package ex2;

public class Circulo extends FormaGeometrica {
    
    public void setRaio(int valor) {
		this.m1 = valor;
		this.m2 = 2*valor;
	}

	public int calcularArea() {
		double area = Math.PI*Math.pow(m1, 2);
		return (int)area;
	}

	public int calcularPerimetro() {
		double perimetro = 	Math.PI*m2;
		return (int) perimetro;
	}

	public String toString() {
		return "Circulo: \n [raio: " + medida1 + ", diametro: " + medida2 + ", Area: " + calcularArea() + ", Perimetro: " + calcularPerimetro() + "]";
	}
}

