package ex2;

public abstract class FormaGeometrica {
	protected int m1;
	protected int m2;
	
	public abstract int calcularArea();
	public abstract int calcularPerimetro();
}
