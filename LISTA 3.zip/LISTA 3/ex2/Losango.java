package ex2;

public class Losango extends FormaGeometrica {
	
	public void setD(int valor) {
		this.m1 = valor;
	}
	
	public void setd(int valor) {
		this.m2 = valor;
	}
	
	public int calcularArea() {
		return m2*m1/2;
	}

	public int calculaPerimetro() {
		double perimetro = 	4*Math.sqrt(Math.pow(m1,2)/4 + Math.pow(m2,2)/4);
		return (int) perimetro;
	}

	public String toString() {
		return "Losango: \n [diagonal 1: " + m1 + ", diagonal 2: " + m2 + ", Area: " + calcularArea() + ", Perimetro: " + calcularPerimetro() + "]";
	}
}