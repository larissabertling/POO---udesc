package ex2;

public class Trapezio extends FormaGeometrica {
	private int altura;

	public void setAltura(int valor) {
		this.altura = valor;
	}

	public void setBaseMenor(int valor) {
		this.m1 = valor;
	}

	public void setBaseMaior(int valor) {
		this.m2 = valor;
	}
	
    public int calcularArea() {
		return (m2 - m1)*altura/2;
	}

	public int calcularPerimetro() {
		double perimetro = 	4*Math.sqrt( Math.pow(((m2 - m1)/2),2));
		return (int) perimetro;
	}

	public String toString() {
		return "Trapezio: \n[altura: " + altura + ", base menor: " + m1 + ", base maior: " + m2 + ", Area: " + calcularArea() + ", Perimetro: " + calcularPerimetro() + "]";
	}
}