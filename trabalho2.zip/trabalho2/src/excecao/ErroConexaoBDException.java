package excecao;

public class ErroConexaoBDException extends Exception {
    public ErroConexaoBDException() {
        super("Falha ao conectar com o banco de dados");
    }

    public ErroConexaoBDException(String mensagem) {
        super(mensagem);
    }

}

