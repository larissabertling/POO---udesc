package excecao;

public class SelectException extends Exception{

    public SelectException(String message){
        super(message);
    }
}