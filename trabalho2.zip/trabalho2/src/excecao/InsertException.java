package excecao;

    public class InsertException extends Exception {
    
        public InsertException(String message){
            super(message);
        }
    }
