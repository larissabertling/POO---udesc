package persistencia;

import dados.*;
import excecao.*;

import java.sql.*;
import java.util.List;
import java.util.LinkedList;

public class GastosDAO {
private static GastosDAO instance = null;

    private PreparedStatement selectNewId;
    private PreparedStatement insert;
    private PreparedStatement select;
    private PreparedStatement selectAll;
    private PreparedStatement selectFromCateg;
    private PreparedStatement selectFromMes;
    private PreparedStatement update;
    private PreparedStatement delete;


private GastosDAO() throws ErroConexaoBDException, ClassNotFoundException, SQLException{
    Connection conexao = Conexao.getConexao();

        selectNewId = conexao.prepareStatement("select nextval('id_gasto')");
        insert = conexao.prepareStatement("insert into gasto values (?,?,?,?,?,?,?)");
        delete = conexao.prepareStatement("delete from gasto where id = ?");
        select = conexao.prepareStatement("select * from gasto where id = ?");
        selectAll = conexao.prepareStatement("select * from gasto where id_usuario = ?");
        selectFromCateg = conexao.prepareStatement("select * from gasto where id_categoria = ? and id_usuario = ?");
        selectFromMes = conexao.prepareStatement("select * from gasto where (substring(data_do_gasto from 4 for 2)) = ? and id_usuario = ?");
        update = conexao.prepareStatement("update gasto set nome = ?, descricao = ?, data_do_gasto = ?, valor = ?, id_categoria = ? where id = ?");

}

public static GastosDAO getInstance() throws ErroConexaoBDException,  ClassNotFoundException, SQLException, SelectException {
    if(instance == null){
        instance = new GastosDAO();
    }
    return instance;
}


private int SelectNewId() throws SelectException {
    try {
        ResultSet rs = selectNewId.executeQuery();
        if(rs.next()){
            return rs.getInt(1);
        }
    } catch (Exception e) {
        throw new SelectException("\nErro ao buscar novo id da tabela gasto! ");
    }

    return 0;
}

public void insert(Gastos gastos) throws InsertException {
    try{
        insert.setInt(1, SelectNewId());
        insert.setString(2, gastos.getNome());
        insert.setString(3, gastos.getDescricao());
        insert.setInt(4, gastos.getCategoria());
        insert.setFloat(5, gastos.getValor());
        insert.setString(6, gastos.getData());
        insert.setInt(7, gastos.getId_usuario());
        insert.executeUpdate();
    } catch (Exception e) {
        throw new InsertException("\nErro ao inserir gasto! ");
    }
}

public List<Gastos> selectAll(int id_logged) throws SelectException {
    List<Gastos> gastos = new LinkedList<Gastos>();

    try {
        selectAll.setInt(1, id_logged);
        ResultSet rs = selectAll.executeQuery();

        while(rs.next()){
            int id = rs.getInt(1);
            String nome = rs.getString(2);
            String descricao = rs.getString(3);
            int id_categoria = rs.getInt(4);
            float valor = rs.getFloat(5);
            String data = rs.getString(6);
            int id_usuario = rs.getInt(7);

            gastos.add(new Gastos(id, nome, descricao, id_categoria, valor, data, id_usuario));
        }

    } catch (Exception e) {
        throw new SelectException("\nErro ao retornar lista de gastos! ");
    }
    return gastos;
}


public Gastos select(int id_gasto) throws SelectException {
    try {
        select.setInt(1, id_gasto);
        ResultSet rs = select.executeQuery();

        if(rs.next()){
            int id = rs.getInt(1);
            String nome = rs.getString(2);
            String descricao = rs.getString(3);
            int id_categoria = rs.getInt(4);
            float valor = rs.getFloat(5);
            String data = rs.getString(6);
            int id_usuario = rs.getInt(7);

            return new Gastos(id, nome, descricao, id_categoria, valor, data, id_usuario);
        }
    } catch (Exception e) {
        throw new SelectException("\nErro ao retornar gasto! ");
    }
    return null;
}

public List<Gastos> selectFromCateg(int cat, int id_logged) throws SelectException {
    List<Gastos> gastosDaCat = new LinkedList<Gastos>();

    try {
        selectFromCateg.setInt(1, cat);
        selectFromCateg.setInt(2, id_logged);
        ResultSet rs = selectFromCateg.executeQuery();

        while(rs.next()){
            int id = rs.getInt(1);
            String nome = rs.getString(2);
            String descricao = rs.getString(3);
            int id_categoria = rs.getInt(4);
            float valor = rs.getFloat(5);
            String data = rs.getString(6);
            int id_usuario = rs.getInt(7);

            gastosDaCat.add(new Gastos(id, nome, descricao, id_categoria, valor, data, id_usuario));
        }

    } catch (Exception e) {
        throw new SelectException("\nErro ao selecionar gastos a partir da categoria! ");
    }
    return gastosDaCat;
}


public List<Gastos> selectFromMes(String mes, int id_logged) throws SelectException {
    List<Gastos> gastosFromMes = new LinkedList<Gastos>();
    try {
        selectFromMes.setString(1, mes);
        selectFromMes.setInt(2, id_logged);
        ResultSet rs = selectFromMes.executeQuery();

        while(rs.next()){
            int id = rs.getInt(1);
            String nome = rs.getString(2);
            String descricao = rs.getString(3);
            int id_categoria = rs.getInt(4);
            float valor = rs.getFloat(5);
            String data = rs.getString(6);
            int id_usuario = rs.getInt(7);

            gastosFromMes.add(new Gastos(id, nome, descricao, id_categoria, valor,  data, id_usuario));
        }
    } catch (Exception e) {
        throw new SelectException("Erro ao selecionar gastos de um mês");
    }
    return gastosFromMes;
}

public void update(Gastos gastos) throws UpdateException {
    try {
        update.setString(1, gastos.getNome());
        update.setString(2, gastos.getDescricao());
        update.setInt(3, gastos.getCategoria());
        update.setFloat(4, gastos.getValor());
        update.setString(5, gastos.getData());
        update.setInt(6, gastos.getId());
        update.executeUpdate();

    } catch (Exception e) {
        throw new UpdateException("\nErro ao atualizar gasto!");
    }
}

public void delete(Gastos gastos) throws DeleteException{

    try {
        delete.setInt(1, gastos.getId());
        delete.executeUpdate();
    } catch (Exception e) {
        throw new DeleteException("\nErro ao deletar gasto!");
    }
}

}

