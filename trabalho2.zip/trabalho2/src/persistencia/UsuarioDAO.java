package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import dados.*;
import excecao.*;

public class UsuarioDAO {
    private static UsuarioDAO instance = null;
    private PreparedStatement selectNewId;
    private PreparedStatement insert;
    private PreparedStatement login;
    private PreparedStatement select;
    private PreparedStatement delete;


 
    public static UsuarioDAO getInstance() throws ErroConexaoBDException, ClassNotFoundException, SQLException{
        if (instance ==null){
            instance = new UsuarioDAO();
        }
        return instance;
    }

    public UsuarioDAO() throws ErroConexaoBDException, ClassNotFoundException, SQLException{
        Connection conexao = Conexao.getConexao();
            selectNewId = conexao.prepareStatement("select nextval('id_usuario')");
            insert = conexao.prepareStatement("insert into usuario values (?,?,?)");
            delete = conexao.prepareStatement("delete from usuario where id = ?");
            login = conexao.prepareStatement("select * from usuario where login = ?");
            select = conexao.prepareStatement("select * from usuario where id = ?");
    
    }


     private int selectNewId() throws SelectException {
        try {
        ResultSet rs = selectNewId.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            }catch (SQLException e){
                throw new SelectException("Erro ao buscar novo id da tabela");
            }
            return 0;
    }

    public Usuario login(String lgn) throws SelectException {
        try {
            login.setString(1, lgn);
            ResultSet rs = login.executeQuery();

            if(rs.next()){
                int id = rs.getInt(1);
                String nome = rs.getString(2);
                int idade = rs.getInt(3);
                String login = rs.getString(4);
                String senha = rs.getString(5);

                return new Usuario(id, nome, idade, login, senha);
            }

        } catch (SQLException e) {
            throw new SelectException("\n(1) Erro ao retornar usuário! ");
        }

        return null;
    }


    public void insert(Usuario usuario) throws InsertException {
        try {       
            
            insert.setInt(1, selectNewId());
            insert.setString(2, usuario.getNome());
            insert.setInt(3, usuario.getIdade());
            insert.setString(4, usuario.getLogin());
            insert.setString(5, usuario.getSenha());
            insert.executeUpdate();
        } catch (Exception e) {
            throw new InsertException("\nErro ao inserir usuário! ");
        }
    }

    public void delete(Usuario usuario) throws DeleteException {
        try {
            login.setString(1, usuario.getLogin());
            ResultSet rs = login.executeQuery();

            if(rs.next()){
                String senha = rs.getString(3);
                if(senha.equals(usuario.getSenha())){
                    System.out.printf(senha+" e "+usuario.getSenha());
                    delete.setInt(1, rs.getInt(1));
                    delete.executeUpdate();
                }
            }
        } catch (Exception e) {
            throw new DeleteException("\nErro ao deletar usuário! ");
        }
    }


    public Usuario select(int id) throws SelectException {
        try {
            select.setInt(1, id);
            ResultSet rs = select.executeQuery();

            if(rs.next()){
                int id_user = rs.getInt(1);
                String nome = rs.getString(2);
                int idade = rs.getInt(3);
                String login = rs.getString(4);
                String senha = rs.getString(5);

                return new Usuario(id_user, nome, idade, login, senha);
            }
        } catch (Exception e) {
            throw new SelectException("\nErro ao retornar usuário! ");
        }
        return null;
    }
}