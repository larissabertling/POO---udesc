package dados;

import java.text.SimpleDateFormat;


public class Gastos {
	
	 private int id;
     private String nome;
     private String descricao;
     private int id_categoria;
     private float valor;
     private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM");
     private String data;
     private int id_usuario;

public Gastos(){
    
}

 
 public Gastos(int id, String nome, String descricao, int id_categoria, float valor, String data, int id_usuario){
    this.id = id;
    this.nome = nome;
    this.descricao = descricao;
    this.id_categoria = id_categoria;
    this.valor = valor;
    this.data = data;
    this.id_usuario = id_usuario;
 }

 public int getId() {
    return this.id;
}

public void setId(int id) {
    this.id = id;
}

 public String getNome() {
     return this.nome;
 }

 public void setNome(String nome) {
     this.nome = nome;
 }

 public String getDescricao() {
     return this.descricao;
 }

 public void setDescricao(String descricao) {
     this.descricao = descricao;
 }
 public float getValor() {
     return this.valor;
 }
 public void setValor(float valor){
     this.valor = valor;
 }

 public String getData(){
    return sdf.format(data);
}

public void setData(String data){
    this.data = data;
}


 public int getCategoria() {
     return this.id_categoria;
}

public void setCategoria(int id_categoria){
    this.id_categoria = id_categoria;
}

public int getId_usuario() {
    return this.id_usuario;
}

public void setId_usuario(int id_usuario) {
    this.id_usuario = id_usuario;
}
    

    public String toString() {
        return "\nID: " + id + "\nNome: " + nome + "\nDescrição: " + descricao + "\nValor: " + valor + "\nData: " + getData() + "Categoria: " + id_categoria;
    }

    
    public static Gastos getInstancia() {
        return null;
    }


    public void add(Gastos gastos) {
    }

}

