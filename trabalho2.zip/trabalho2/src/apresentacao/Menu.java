package apresentacao;

import dados.*;
import negocio.*;
import excecao.*;
import java.util.*;
import java.sql.*;

public class Menu {
    static Sistema sistema = null;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        try {
            sistema = Sistema.getInstancia();
        } catch (ErroConexaoBDException erro) {
            System.out.println(erro);
        }

        for (;;) {
            mostrarOpcoes();
            int op = Integer.parseInt(sc.nextLine());
            switch (op) {
            case 1:
                Sistema.addGasto();
                break;

            case 2:
                Sistema.selectGastoFromMes();
                break;

            case 3:
                Sistema.selectGastoFromCategoria();
                break;

            case 4:
                Sistema.removeGasto();
                break;

            case 5:
                Sistema.updateGasto();
                break;

            case 0:
                return;

            default:
                System.out.println("Opcao invalida!");
                break;
            }
        }
    }

    private static void cadastrarGasto() {
        System.out.println("\nCADASTRANDO GASTO");
        try {
            Menu.criarOuEditarGasto();
            sistema.addGasto();
        } catch (InsertException erro) {
            System.out.println("Erro ao cadastrar\n" + erro);
        }
    }

    private static void filtrarMes() {
        try {
            System.out.println("Digite o n�mero correspondente ao m�s:");
            Integer mes = Integer.parseInt(sc.nextLine());
            List<Gastos> lista = sistema.selectGastosFromMes(mes);
            System.out.println(lista);
        } catch (SelectException erro) {
            System.out.println(erro);
        }
    }

    private static void filtrarCategoria() {
        try {
            Menu.mostrarCategorias();
            Integer categoria = Integer.parseInt(sc.nextLine());
            List<Gastos> lista = sistema.selectGastosFromCategoria(cat);
            System.out.println(lista);
        } catch (SelectException erro) {
            System.out.println(erro);
        }
    }

    private static void removerGasto() {
        Menu.mostrarLista();
        System.out.println("Digite o ID correspondente ao gasto a ser removido");
        int indice = Integer.parseInt(sc.nextLine());
        try {
            sistema.removeGasto(indice);
        } catch (DeleteException erro) {
            System.out.println(erro);
        }
    }

    private static void alterarGasto() {
        System.out.println("\nEDITANDO GASTO");
        try {
            Menu.mostrarLista();
            System.out.println("Digite o ID correspondente ao gasto a ser alterado");
            int indice = Integer.parseInt(sc.nextLine());
            Menu.criarOuEditarGasto();
            sistema.updateGasto(indice);
        } catch (Exception erro) {
            System.out.println("Erro ao cadastrar\n" + erro);
        }
    }

    private static void mostrarLista() {
        try {
            System.out.println(sistema.getGastos());
        } catch (SelectException erro) {
            System.out.println(erro);
        }

    }

    private static void criarOuEditarGasto(){
        mostrarCategorias();
        int categoria = Integer.parseInt(sc.nextLine());
        System.out.println("Digite o nome:");
        String nome = sc.nextLine();
        System.out.println("Digite uma breve descricao:");
        String descricao = sc.nextLine();
        System.out.println("Digite o valor:");
        Float valor = Float.parseFloat(sc.nextLine());
        System.out.print("Data (dd/mm/aaaa):");
        String data = sc.nextLine();
        sistema.setGastos(nome, descricao, valor, data, categoria);
    }

    private static void mostrarOpcoes() {
        System.out.println("\nDigite a opcao desejada:");
        System.out.println("[1] - Cadastrar despesa");
        System.out.println("[2] - Filtrar mes");
        System.out.println("[3] - Filtrar categoria");
        System.out.println("[4] - Remover um gasto");
        System.out.println("[5] - Alterar dados de um gasto");
        System.out.println("[0] - Sair");
    }

    private static void mostrarCategorias() {
        System.out.println("\nDigite a categoria desejada:");
        System.out.println("[1] - Alimentacao");
        System.out.println("[2] - Saude");
        System.out.println("[3] - Transporte");
        System.out.println("[4] - Lazer");
        System.out.println("[5] - Educacao");
        System.out.println("[6] - Outros");
    }
}