import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class ListaPessoas {
	ArrayList<Pessoa> crianca_0 = new ArrayList<Pessoa>();
	ArrayList<Pessoa> adolecentes_1 = new ArrayList<Pessoa>();
	ArrayList<Pessoa> jovens_2 = new ArrayList<Pessoa>();
	ArrayList<Pessoa> adultos_3 = new ArrayList<Pessoa>();
	ArrayList<Pessoa> idosos_4 = new ArrayList<Pessoa>();
	
	
	public void cadastraPessoa(Pessoa pessoa) {
		switch (pessoa.getFaixaEtaria()) {
		case 0:
			crianca_0.add(pessoa);
			crianca_0.sort(Comparator.comparing(Pessoa::getIdade));
			break;
		case 1:
			adolecentes_1.add(pessoa);
			adolecentes_1.sort(Comparator.comparing(Pessoa::getIdade));
			break;
		case 2:
			jovens_2.add(pessoa);
			jovens_2.sort(Comparator.comparing(Pessoa::getIdade));
			break;
		case 3:
			adultos_3.add(pessoa);
			adultos_3.sort(Comparator.comparing(Pessoa::getIdade));
			break;
		case 4:
			idosos_4.add(pessoa);
			idosos_4.sort(Comparator.comparing(Pessoa::getIdade));
			break;
		default:
			System.out.println("Não classificado!");
			break;
		}
	}
}

    public static Pessoa adicionaPessoa(){
        Pessoa pessoa = new Pessoa();

        System.out.println("\nDigite o nome: ");
        pessoa.setNome(sc.nextLine());
        System.out.println("Digite o CPF: ");
        pessoa.setCpf(sc.nextLine());
        System.out.println("Digite a idade: ");
        pessoa.setIdade(Integer.parseInt(sc.nextLine()));
        System.out.println("Digite a cidade: ");
        pessoa.setCidade(sc.nextLine());

        return pessoa;
    }
