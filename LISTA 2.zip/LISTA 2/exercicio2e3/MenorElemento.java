import java.util.*;

public class MenorElemento {
	static Scanner userInput = new Scanner(System.in);
	public static void main(String[] args) {
		int parada = 0;
		int tam = 2;
		int readElemento;
		Matriz<Integer> menorDaMatriz = new Matriz<>(tamanho,tamanho);
		int i = 0;
		while (parada != -1) {
			    for(int j = 0; j<tam; j++) {
			    	System.out.println("Digite um elemento para a matriz: ");
			    	leElemento = Integer.parseInt(userInput.nextLine());
			    	if(!menorDaMatriz.set(readElemento, i, j)) {
			    		System.out.println("Matriz está cheia!");
			    	}
			    	parada = paraOuContinua();
			    	if (parada == -1)break;
			    }
			i++;
		}
		System.out.println("O menor elemento da matriz é: " + menorElementoMatriz(menorDaMatriz));
	}
	
	public static int menorElementoMatriz(Matriz<Integer> procuraMenor) {
		List<Integer> menorDosQuadrantes = new ArrayList<>();
		menorDosQuadrantes.add(menorElementoLista(procuraMenor.getElementosQuadrante(Quadrante.PRIMEIRO)));
		menorDosQuadrantes.add(menorElementoLista(procuraMenor.getElementosQuadrante(Quadrante.SEGUNDO)));
		menorDosQuadrantes.add(menorElementoLista(procuraMenor.getElementosQuadrante(Quadrante.TERCEIRO)));
		menorDosQuadrantes.add(menorElementoLista(procuraMenor.getElementosQuadrante(Quadrante.QUARTO)));
		return menorElementoLista(menorDosQuadrantes);
	}
	
	public static int menorElementoLista(List<Integer> lista) {
	    if (lista == null || lista.size() == 0)
            return Integer.MAX_VALUE; 
        List<Integer> sortedlist = new ArrayList<>(lista);
        Collections.sort(sortedlist);
        return sortedlist.get(0);
	}
	public static int paraOuContinua(){ 
        System.out.println("Digite -1 se quiser parar");
        String s = userInput.nextLine();
        if (s.equals("-1"))
        	return -1;
        else return 0;
	}

}
