import java.util.ArrayList;
import java.util.List;


public class Matriz<T>{

    private int m;
    private int n;
    private T[][] matrizT = null;

    public Matriz(int m, int n) {
        T[][] matriz = (T[][])(new Object[m][n]);
        this.m = m;
        this.n = n;
        this.matrizT = matriz;
    }
    
    public boolean set(T objeto, int i, int j){
        if(i>m || j>n)
            return false;
        
        else{
            this.matrizT[i][j] = objeto;
            return true;
        }
    }
    
    public T get(int i, int j){
        return this.matrizT[i][j];
    }
    
    public List<T> getLinha(int linha){
        List<T> aux = new ArrayList<T>();

        for(int j = 0; j<m; j++){
            if(matrizT[linha][j]!= ""){
                aux.add(matrizT[linha][j]);
            }
        }

        return aux;
    }
    
    public List<T> getColuna(int coluna){
        List<T> aux = new ArrayList<T>();

        for(int i = 0; i<n; i++){
            if(matrizT[i][coluna]!= "")
                aux.add(matrizT[i][coluna]);
        }

        return aux;
    }

    public enum Quadrante {
        PRIMEIRO, SEGUNDO, TERCEIRO, QUARTO;
}

List<T> getElementosQuadrante(Quadrante quadrante){
    int meioLinha = m/2+m%2;
    int meioColuna = n/2 + n%2;
    List<T> quadranteList = new ArrayList<>();;
    if(quadrante == Quadrante.PRIMEIRO) {
        for(int i = 0; i<meioLinha; i++){
            for(int j = 0; j<meioColuna; j++)
                quadranteList.add(matrizT[i][j]);
        }
    }
    if(quadrante == Quadrante.SEGUNDO) {
        for(int i = 0; i<meioLinha; i++){
            for(int j = meioColuna; j<n; j++)
                quadranteList.add(matrizT[i][j]);
        }
    }
    if(quadrante == Quadrante.TERCEIRO) {
        for(int i = meioLinha; i<m; i++){
            for(int j = 0; j<meioColuna; j++)
                quadranteList.add(matrizT[i][j]);
        }
    }	
    if(quadrante == Quadrante.QUARTO) {
        for(int i = meioLinha; i<m; i++){
            for(int j = meioColuna; j<n; j++)
                quadranteList.add(matrizT[i][j]);
        }
    }
    return quadranteList;
}
}
    