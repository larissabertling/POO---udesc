import java.util.Arrays;

public class Equipe {
	private String nome;
	private Aluno participantes[];
	
	public Equipe(Aluno a1, Aluno a2, Aluno a3, Aluno a4) {
		if (a4 != null) {
			this.participantes = new Aluno[4];
			this.participantes[3] = a4;
		}
		else this.participantes = new Aluno[3];
		this.participantes[0] = a1;
		this.participantes[1] = a2;
		this.participantes[2] = a3;
		Arrays.sort(participantes);
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Aluno[] getParticipantes() {
		return participantes;
	}
	
	public String toString() {
		String s = "";
		for (int i = 0; i < participantes.length; i++)
		   s += participantes[i];
		return s;
	}
}