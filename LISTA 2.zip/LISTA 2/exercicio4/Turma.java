import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Turma{
    static Scanner sc = new Scanner(System.in);
    static List<Aluno> listaDeAlunos = new ArrayList<Aluno>();
    static List<Par<Aluno>> lista = new Par (Object(List<Par<Aluno>>));
    public static void main(String[] args){
        for(;;){

            Aluno aluno = new Aluno();
        
            System.out.println("\nDigite o nome: ");
            aluno.setNome(sc.nextLine());
            System.out.println("Digite a idade: ");
            aluno.setIdade(Integer.parseInt(sc.nextLine()));
            adicionarAluno(aluno);


            System.out.println("Digite 1 para adicionar mais um aluno e -1 para concluir");
            int op = Integer.parseInt(sc.nextLine());
            if(op == -1){
            }
        }
    }

    static void adicionarAluno(Aluno aluno){
        lista.add(aluno);
    }

    public List<Equipe> separarEmEquipes() {
		int equipesDe3 = listaDeAlunos.size()/3;
		int equipesDe4 = listaDeAlunos.size()%3;
		List<Equipe> listaDeEquipes = new ArrayList<>();
		int menorMedia = listaDeAlunos.size();
		int maiorMedia = 0;
		for (int i = 0; i < equipesDe3; i++) {
			listaDeEquipes.add(new Equipe(listaDeAlunos.get(maiorMedia), listaDeAlunos.get(maiorMedia+1), listaDeAlunos.get(menorMedia), null));	
			maiorMedia+=2;
			menorMedia--;
		}
		for (int i = 0; i < equipesDe4; i++) {
			listaDeEquipes.add(new Equipe(listaDeAlunos.get(maiorMedia), listaDeAlunos.get(maiorMedia+1), listaDeAlunos.get(menorMedia), listaDeAlunos.get(menorMedia-1)));	
			maiorMedia+=2;
			menorMedia-=2;
		}
		return listaDeEquipes;	
	}

    public static Turma novoAluno(Turma turma) {
		Aluno a = new Aluno();
		
		System.out.println("Digite o nome: ");
		String leStrings = userInput.nextLine();
		a.setNome(leStrings);
		
		System.out.println("Digite a idade: ");
		leStrings = userInput.nextLine();
		a.setIdade(Integer.parseInt(leStrings));
		
		double leNotas[] = new double[5];
		for (int i = 0; i < 5; i++) {
			System.out.println("Digite a nota " + (i+1) + ": ");
			leNotas[i] = Double.parseDouble(userInput.nextLine());
		}
		a.setNotas(leNotas);
		
		turma.adicionaAluno(a);
		
		return (turma);
	}
}