import java.util.Comparator;

public class Aluno implements Comparator<Aluno>{
	private String nome;
	private int idade;
	private double notas[] = new double[5];
	
	
	public String getNome() {
		return nome;
    }
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public double[] getNotas() {
		return notas;
	}
	public void setNotas(double[] notas) {
		this.notas = notas;
	}
	
	public double calcularMedia() {
		return ((notas[0]+notas[1]+notas[2]+notas[3]+notas[4])/5);
	}
	
	public String toString() {
		return "\n- " + nome + ", " + idade + " anos, Média: " + calcularMedia();
	}
}
