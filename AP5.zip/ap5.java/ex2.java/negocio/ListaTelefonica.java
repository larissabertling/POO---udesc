//CODIGO FEITO EM SALA

package negocio;

import java.util.Map;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import dados.Contato;

public class ListaTelefonica {

    private Map <Character, List<Contato>> contatos = new HashMap <Character, List<Contato>> ();

    public ListaTelefonica() {

        List<Contato> lista;

        for (char i = 'A'; i <='Z'; i++){
            lista = new LinkedList <Contato>();
            contatos.put(i, lista);
        }
    }

    public void addContato(Contato contato){
        String nome = contato.getNome().toUpperCase();    //Retorna tudo em letra Maiúscula

        List<Contato> contatosTemp = contato.get(nome.charAt(0));  //charAt0, busca o caracter na posição informada

        contatosTemp.add(contato);
    }

    public void removeContato(Contato contato){
        String nome = contato.getNome() . toUpperCase();

        contatos.get(nome.charAt(0)). remove(contato);

    }

    public List<Contato> buscarContatos (char letra){
        return contatos.get(Character.toUpperCase(letra));
    }
    public Map<Character, List<Contato>> buscarContatos(){
        return contatos;
    }

}



    //private static void addContato(contato : Contato);
    //private static void removerContato(contato : Contato);
    //private String buscarContatos(letra : char) : List <Contato>
    //private buscarContatos[] : Map <Character, List <Contato>>
