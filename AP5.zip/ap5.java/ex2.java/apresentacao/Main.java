package apresentacao;

import dados.Contato;
import negocio.ListaTelefonica;

public class Main {
    
    public static void ImprimeMenu () {
        System.out.println(" -------- Lista Telefonica -------- ");
        System.out.println("Selecione uma ação: ");
        System.out.println("0 - Sair da Lista Telefonica");
        System.out.println("1 - Adicionar Contato");
        System.out.println("2 - Remover Contato");
        System.out.println("3 - Exibir Contatos");
    }
public static void main (String [] args){
    int opcao = -1;
    while (opcao != 0){
        switch (opcao){
            case 0:
            break;
            case 1:
            addContato;
            break;
            case 2:
            removerContato;
            break;
            case 3:
            exibirContatos;
            break;
        }
    }
    public static void exibirContatos(){
        lista.buscarContatos().forEach((chave, contatos) -> {
            System.out.println(chave + ":");

            contatos.forEach
        }
    }

    public static void addContato(){
         lista.addContato().forEach((chave, contatos) -> {
            System.out.println(chave + ":");

            contatos.forEach

         }
        }
    public static void removerContato(){
        lista.removerContato().forEach((chave, contatos) -> {
            System.out.println(chave + ":");
   
            contatos.forEach
    }
}
}