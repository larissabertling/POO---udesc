package ex2.negocio;

import java.util.List;
import ex2.dados.*;
import ex2.persistencia.ContatoDAO;
import java.util.Map;


public class ListaTelefonica {

    private ContatoDAO contatoDAO = new ContatoDAO();

    public void addContato(Contato contato) {
        contatoDAO.addContato(contato);
    }

    public void removeContato(Contato contato) {
        contatoDAO.removerContato(contato);
    }

    public List<Contato> buscarContatos(char letra) {
        return contatoDAO.getAll().get(letra);
    }
    
    public Map<Character, List<Contato>> buscarContatos() {
        return contatoDAO.getAll();
    }
}
