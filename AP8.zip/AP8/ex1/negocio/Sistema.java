package ex1.negocio;

import java.util.List;
import ex1.dados.Pessoa;
import ex1.persistencia.PessoaDAO;

public class Sistema {
    
    private PessoaDAO pessoaDAO = new PessoaDAO();

    public void adicionarPessoa(Pessoa p){
        pessoaDAO.insert(p);
    }
    public void removerPessoa(Pessoa p){
        pessoaDAO.delete(p);
    }
    public List<Pessoa>getLista(){
        return pesssoaDAO.getAII();
    }
}
