package interface;

public class AbstractTableModel {
    
}
