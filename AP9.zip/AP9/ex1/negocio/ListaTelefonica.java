package ex1.negocio;

import java.util.List;
import java.util.Map;

import ex1.dados.*;
import ex1.exception.*;
import ex1.persistencia.*;


public class ListaTelefonica {

    private ContatoDAO contatoDAO = new ContatoDAO();

    public void adicionaContato(Contato contato) throws ContatoJaCadatradoException, ErroNaLeituraException, ErroNaGravacaoException{
        contatoDAO.adicionaContato(contato);
    }

    public void removeContato(Contato contato) throws ContatoNaoCadastradoException, ErroNaGravacaoException, ErroNaLeituraException {
        contatoDAO.removerContato(contato);
    }

    public List<Contato> buscarContatos(char letra) throws ErroNaLeituraException{
        return contatoDAO.getAll().get(letra);
    }
    
    public Map<Character, List<Contato>> buscarContatos() throws ErroNaLeituraException{
        return contatoDAO.getAll();
    }
}
