package ex2.exception;

import java.lang.Exception;


public class EspacoIndisponivelException extends Exception {
	public EspacoIndisponivelException() {
		
	}
	public EspacoIndisponivelException(String mensagem) {
		super(mensagem);
	}

}