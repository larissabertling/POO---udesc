package dados;

public class ContaCorrente extends ContaBancaria {
    
    private int cpf;
    
    public int getCpf(){
        return cpf;
    }
    public void setCpf (int cpf){
        this.cpf = cpf;
    }
    public ContaCorrente(){
        super();
    }
        public boolean depositar (float valor) {
        this.saldo += valor;
        return true;
    }
    @Override
    public String gerarExtrato () {
        return "Conta Corrente: \n" + "CPF: " + this.getCpf() + "\n" + super.gerarExtrato(); 
    }
    @Override
    public String toString(){
        return "Conta Corrente: \n" + super.toString();
    }
}
